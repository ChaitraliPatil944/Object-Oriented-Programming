﻿
namespace LMS;
public class Program
{
    public static void Main(string[] args)
    { 

        
         
    }
}